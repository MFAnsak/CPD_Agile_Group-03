-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2021 at 11:21 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodorderigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `email`, `date`) VALUES
(1, 'admin', '$2y$10$mI/hpZ59vGgjs/lPTQWLJu.I82O93AEJ3gwFycAjuibOjAGi9dcTm', 'admin123@gmail.com', '2021-02-26 16:24:50');

-- --------------------------------------------------------

--
-- Table structure for table `dishesh`
--

CREATE TABLE `dishesh` (
  `d_id` int(11) NOT NULL,
  `r_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `about` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dishesh`
--

INSERT INTO `dishesh` (`d_id`, `r_id`, `name`, `about`, `price`, `img`) VALUES
(33, 23, 'Ramen', 'Ramen is a Japanese noodle soup. It consists of Chinese-style wheat noodles served in a meat or fish-based broth, often flavored with soy sauce or miso, and uses toppings such as sliced pork, nori, menma, and scallions.', 1000, '1200px-Shoyu_Ramen.jpg'),
(35, 24, 'Sarma', 'Sarma, commonly marketed as stuffed grape leaves, is a type of dolma', 700, '1200px-Etli_yaprak_sarma_-_yogurt1.jpg'),
(36, 25, 'Tom Yum', 'Tom yum or tom yam is a type of hot and sour Thai soup, usually cooked with shrimp. Tom yum has its origin in Thailand. The words \"tom yam\" are derived from two Thai words.', 300, 'Tom_yam_kung_maenam.jpg'),
(37, 26, 'Laksa', 'Laksa is a spicy noodle dish popular in Southeast Asia. Laksa consists of various types of noodles, most commonly thick rice noodles, with toppings such as chicken, prawn or fish. Most variations of laksa are prepared with a rich and spicy coconut soup or', 450, 'www.jpg'),
(38, 27, 'Ceviche', 'Ceviche, also cebiche, seviche, or sebiche is a South American seafood dish that originated in Peru, typically made from fresh raw fish cured in fresh citrus juices, most commonly lemon or lime, but historically made with the juice of bitter orange.', 1500, '1200px-Cebiche_de_corvina.jpg'),
(39, 29, 'Pizza Margherita', 'Pizza Margherita (more commonly known in English as Margherita pizza) is a typical Neapolitan pizza, made with San Marzano tomatoes, mozzarella cheese, fresh basil, salt, and extra-virgin olive oil.', 1200, 'download.jpg'),
(40, 31, 'Gyoza', 'Gyoza (餃子), or Japanese pan-fried dumplings, are as ubiquitous as ramen in Japan. You can find these mouthwatering dumplings being served at specialty shops, izakaya, ramen shops, grocery stores or even at festivals.', 1350, 'gyoza.jpg'),
(41, 23, 'tacos al pastor', 'Al pastor (from Spanish, \"shepherd style\"), also known as tacos al pastor, is a taco made with spit-grilled pork. Cooking method is based on the lamb shawarma brought by Lebanese immigrants to Mexico, al pastor features a flavor palate that uses tradition', 1000, '20210712-tacos-al-pastor-melissa-hom-seriouseats-37-f72cdd02c9574bceb1eef1c8a23b76ed.jpg'),
(42, 24, 'Gyros', 'Gyros or sometimes gyro is a Greek dish made from meat cooked on a vertical rotisserie. Like shawarma and al pastor meat, it is originally derived from the lamb-based doner kebab', 800, '1200px-Pita_giros.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `r_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `o_hr` varchar(255) NOT NULL,
  `c_hr` varchar(255) NOT NULL,
  `o_days` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `img` text NOT NULL,
  `IsApproved` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`r_id`, `c_id`, `username`, `name`, `phone`, `password`, `o_hr`, `c_hr`, `o_days`, `address`, `img`, `IsApproved`) VALUES
(23, 7, 'caferobot', 'Cafe robot', '0784567834', '$2y$10$wCxHGqfOap6o8.PlXSxGuu1xPUl7yhwFp4ZEMlVHIZdLzvj3kHKUG', '11am', '8pm', '24hr-x7', '795/A, Seeduwa', 'artisan-cafe-berea-ky1.jpg', 1),
(24, 7, 'cafepaprika', 'Cafe Paprika', '0771234567', '$2y$10$ryYy9NSAdCdbVXVJq9bPBOBM8V.4QGborNPZakB/XFuR.nOeEkcMa', '8am', '8pm', '24hr-x7', 'No 80, Tennekumbura', 'grestro2.jpg', 1),
(25, 8, 'mantismart', 'Mantis Mart & Cafe', '0785678345', '$2y$10$F1Oi6c21ididvWhjPvOzE.iCONXxcoj/uxCXJuBpFy8h.Q63dcB7W', '10am', '11pm', 'mon-fri', '734, Lake Road, Boralesgamuwa, Maharagama 10280', 'hlmg1.jpg', 1),
(26, 7, 'bubbletea', 'Bubble Me Bubble Tea', '0784567834', '$2y$10$36RUsnTg2pO2T9aKuTRDQ.bJ3a.tz8K3FJa8XScivEQ06hiBT4yQC', '6am', '7pm', 'mon-fri', '106 Thimbirigasyaya Rd, Colombo 00500', 'icnr2.jpg', 1),
(27, 6, 'hogwarts', 'Hogwarts Cafe Gampaha', '0784567834', '$2y$10$3BQb/Dg/lIUEcZXHokd2kOxJ7gg39i46gdQ3WzcE7ggyZxgdUGy.C', '11am', '8pm', '24hr-x7', 'Gampaha Fly Over, Gampaha', 'TOWNSEND1.jpg', 1),
(29, 8, 'admin', 'Lakmal\'s Pizza Kitchen', '0112345673', '$2y$10$z9mXVBIyqlf1pLaoUf.TO.mvWcT4SkARUWQzcGwadpZSMpqViD9Pa', '6am', '10pm', 'mon-fri', 'CP, Hasalaka', 'treehouserestr1.jpg', 1),
(31, 6, 'admin', 'The burger Hub', '0112345642', '$2y$10$7IdQDFKcrsbqQZo8oiRnQuhi0GbujIP/Sr7txd6UpiX6Pu/FAhstO', '10am', '6pm', 'mon-fri', '65 Prasanna Mawatha, Kandy', 'vrfnb1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `res_category`
--

INSERT INTO `res_category` (`c_id`, `c_name`) VALUES
(6, 'Indian'),
(7, 'Sri Lankan'),
(8, 'chinese');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`) VALUES
(45, 'Ansak', 'Ansak', 'Ahamed', 'aannssaakk@gmail.com', '0770773935', '$2y$10$mx/dNJoJyONDh4HdImm7ZObGEOPR1VrSdDB2aPbvKiovcxJfEPd0.', '69,Kurunegala Road, Galgamuwa'),
(46, 'Aruna', 'Aruna', 'Rathnayake', 'aruna1rathnayake@gmail.com', '0769867456', '$2y$10$nQJlPdnAqKnUZU/B3TQ5KePes5eWybNEDsx83RthkaQjr9ST6Gd9C', 'No. 2/2, Herakola, Kandy'),
(47, 'Avish', 'Avish', 'Malinda', 'avish@gmail.com', '0788762456', '$2y$10$h//ea83NhIVzHwJI12uNpuxqTOqYzj9yyNbSAB1ZwVQAq7a.m2v/i', 'No, 56, Primrose rd. , Kandy'),
(48, 'Vishwa', 'Vishwa', 'Ranil', 'vishwaranil@gmail.com', '0781234567', '$2y$10$M8xmvguqD7pPOlLiUS9CPuqT02CfortdtJbIPnfFpjdVI52A6NQBe', 'No, 3/5, Hatharaliyadda, Kandy'),
(49, 'Adikari', 'Chathuka', 'Adikari', 'adikari@outlook.com', '0786754563', '$2y$10$OY7nu7vpk73IN950/xKxO.022UerFqaZUzk7D/LEtehr9OtVyuIl.', 'No. 53, Gregory park, Gampaha'),
(50, 'Uditha', 'Uditha', 'Dasanayake', 'uditha@outlook.com', '0751234567', '$2y$10$GmHb1M1yg5b7eBfcaSLibeqhd2eaOXBSSXXj7Yy8EWVsqyx/MsL9m', 'No. 2/3, Galaha rd, Peradeniya'),
(51, 'Ridmi', 'Ridmi', 'Withanage', 'ridmi@gmail.com', '0789087654', '$2y$10$iQvh46G7JMItf15t1Kd3PeJs8yIfzep75NPo1KF2zgeZAEyYNhbS2', 'No. 5, High level street, Colombo'),
(52, 'Ashan', 'Ashan', 'Keerthi', 'ashan@outlook.com', '0781234567', '$2y$10$pWmN0PwXEHWIKnuA3mj6sOnOL2pgjv5Y6wn5MjV.DgMHrLKpw48em', 'No. 2/3, Halagama, Gampola'),
(53, 'Lochana', 'Lochana', 'Jayaweera', 'lochana@sniptik.lk', '0784567834', '$2y$10$9VpCsCyIk4GGYxKJSp3ALu6jVTCs8cESiIgVoC91lcajWw0DC5X8q', 'No. 34, main rd., Ulapane'),
(54, 'Sanduni', 'Sanduni', 'Perera', 'sanduni@apiit.lk', '0786785674', '$2y$10$49nIwygvl.9O1X.T/MZasuG45idoYxzTnv3.OkQGXy2PPZg4E455O', 'No. 45, Galwaththa. Galewela');

-- --------------------------------------------------------

--
-- Table structure for table `user_orders`
--

CREATE TABLE `user_orders` (
  `o_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `d_id` int(11) NOT NULL,
  `d_name` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL,
  `price` float NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `success-date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `r_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `dishesh`
--
ALTER TABLE `dishesh`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `user_orders`
--
ALTER TABLE `user_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dishesh`
--
ALTER TABLE `dishesh`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `user_orders`
--
ALTER TABLE `user_orders`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
