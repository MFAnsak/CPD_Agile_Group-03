<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Profile extends CI_Controller {

    function __construct(){
        parent::__construct();

            $restaurent_user = $this->session->userdata('restaurent_user');
            if(empty($restaurent_user)) {
                $this->session->set_flashdata('msg', 'Your session has been expired');
                redirect(base_url().'restuarent_owners/login/index');
            }
            
        $this->load->model('Store_model');
        $this->load->model('User_model');
    }

    public function index() {
        $restaurent_user = $this->session->userdata('restaurent_user');
        $user = $this->Store_model->getByUsername($restaurent_user['username']);
         $data['user'] = $user;
        $this->load->view('restuarent_owners/partials/header');
        $this->load->view('restuarent_owners/profile', $data);
        $this->load->view('restuarent_owners/partials/footer');
    }

    
    public function editPassword($id) {
        $user = $this->Store_model->getStore($id);

        if(empty($user)) {
            $this->session->set_flashdata('error', 'User not found');
            redirect(base_url().'restuarent_owners/profile');
        }

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('cPassword', 'Current password','trim|required');
        $this->form_validation->set_rules('nPassword', 'New password','trim|required');
        $this->form_validation->set_rules('nRPassword', 'New password','trim|required');

        if($this->form_validation->run() == true) { 
            $cPassword = $this->input->post('cPassword');
            $nPassword = $this->input->post('nPassword');
            $nRPassword = $this->input->post('nRPassword');
            if(password_verify($cPassword, $user['password']) == true) {
                if($nPassword != $nRPassword) {
                    $this->session->set_flashdata('pwd_error', 'password not match');
                    redirect(base_url(). 'restuarent_owners/profile/index');
                }else {
                    $formArray['password'] = password_hash($this->input->post('nPassword'), PASSWORD_DEFAULT);

                    $this->Store_model->update($id,$formArray);
                    $this->session->set_flashdata('pwd_success', 'Password updated successfully');
                    redirect(base_url(). 'restuarent_owners/profile/index');
                }
            }else {
                $this->session->set_flashdata('pwd_error', 'Your old password is incorrect');
                redirect(base_url(). 'restuarent_owners/profile/index');
            }
        }else {
            $data['user'] = $user; 
            $this->load->view('restuarent_owners/partials/header');
            $this->load->view('restuarent_owners/profile', $data);
            $this->load->view('restuarent_owners/partials/footer');
        }
    }
}