<?php
defined('BASEPATH') OR exit ('No direct script access allowed');



class Home extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $restaurent_user = $this->session->userdata('restaurent_user');
        if(empty($restaurent_user)) {
            $this->session->set_flashdata('msg', 'Your session has been expired');
            redirect(base_url().'/restuarent_owners/login');
        }
    }
    public function index() {
  
        $this->load->view('restuarent_owners/partials/header');
        $this->load->view('restuarent_owners/dashboard');
        $this->load->view('restuarent_owners/partials/footer');
    }

   
    
   
    
    
}
