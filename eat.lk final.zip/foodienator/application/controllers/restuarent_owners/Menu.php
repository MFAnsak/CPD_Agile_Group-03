<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Menu extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $restaurent_user = $this->session->userdata('restaurent_user');
        if(empty($restaurent_user)) {
            $this->session->set_flashdata('msg', 'Your session has been expired');
            redirect(base_url().'restuarent_owners/login/index');
        }
       
    }

    public function index() {
        $this->load->model('Menu_model');
        $restaurent_user = $this->session->userdata('restaurent_user');
        $dishesh = $this->Menu_model->getDishesh($restaurent_user['user_id']);
        $data['dishesh'] = $dishesh;
        $this->load->view('restuarent_owners/partials/header');
        $this->load->view('restuarent_owners/menu/list', $data);
        $this->load->view('restuarent_owners/partials/footer');
    }

    public function create_menu(){

        $this->load->helper('common_helper');
        $this->load->model('Store_model');
        $store = $this->Store_model->getStores();

        $config['upload_path']          = './public/uploads/dishesh/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        

        $this->load->library('upload', $config);

        $this->load->model('Menu_model');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('name', 'Dish name','trim|required');
        $this->form_validation->set_rules('about', 'About','trim|required');
        $this->form_validation->set_rules('price', 'Price','trim|required');
        


        if($this->form_validation->run() == true) {

            if(!empty($_FILES['image']['name'])){
                
                if($this->upload->do_upload('image')) {
                    
                    $data = $this->upload->data();
                    
                    resizeImage($config['upload_path'].$data['file_name'], $config['upload_path'].'thumb/'.$data['file_name'], 300,270);

                    resizeImage($config['upload_path'].$data['file_name'], $config['upload_path'].'front_thumb/'.$data['file_name'], 1120,270);

                    $restaurent_user_id = $this->session->userdata('restaurent_user');
                    $formArray['img'] = $data['file_name'];
                    $formArray['name'] = $this->input->post('name');
                    $formArray['about'] = $this->input->post('about');
                    $formArray['price'] = $this->input->post('price');
                    $formArray['r_id'] =   $restaurent_user_id['user_id'];
        
                    $this->Menu_model->create($formArray);
        
                    $this->session->set_flashdata('dish_success', 'Menu added successfully');
                    redirect(base_url(). 'restuarent_owners/menu/index');

                } else {
                    
                    $error = $this->upload->display_errors("<p class='invalid-feedback'>","</p>");
                    $data['errorImageUpload'] = $error; 
                    $data['stores']= $store;
                    $this->load->view('restuarent_owners/partials/header');
                    $this->load->view('restuarent_owners/menu/add_menu', $data);
                    $this->load->view('restuarent_owners/partials/footer');
                }

                
            } else {
                
                $restaurent_user_id = $this->session->userdata('restaurent_user');
                $formArray['name'] = $this->input->post('name');
                $formArray['about'] = $this->input->post('about');
                $formArray['price'] = $this->input->post('price');
                $formArray['r_id'] =   $restaurent_user_id['user_id'];
    
                $this->Menu_model->create($formArray);
                
                $this->session->set_flashdata('dish_success', 'Dish added successfully');
                redirect(base_url(). 'restuarent_owners/menu/index');
            }

        } 
        else {
            $store_data['stores']= $store;
            $this->load->view('restuarent_owners/partials/header');
            $this->load->view('restuarent_owners/menu/add_menu', $store_data);
            $this->load->view('restuarent_owners/partials/footer');
        }
        
    }

    
    
    

    
    
        
    

    
    
    

    

    
    
    

    

    
    
    
    
    
    

    

    
    
    
    
    
    
    

    
    
    
    
    
        
    

    

    
    
    

    
    
    
        
    
    

    
    
    
    
    
    
    
    
    
    

                
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    

    

    
    

    
    

    
    
    
    

    
    
    

    
    
    

    

    
    

    
}