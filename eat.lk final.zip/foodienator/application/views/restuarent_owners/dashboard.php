<div class="container">
    <h2>Welcome to Restaurant Panel</h2>
</div>