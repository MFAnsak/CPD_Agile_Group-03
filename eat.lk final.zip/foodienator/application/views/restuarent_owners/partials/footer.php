   
    <footer  class="section p-3 bg-dark text-white fixed-bottom">
        <div class="text-center">&copy; Copyright <?php echo date("Y"); ?> EAT.lk</div>
    </footer>
</body>
</html>